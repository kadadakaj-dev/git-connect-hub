import "reflect-metadata";
import * as dotenv from "dotenv";
dotenv.config();

import { ValidationPipe } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import { ApiKeyGuard } from "./api-key.guard";
import { GlobalErrorFilter } from "./global-error.filter";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import * as crypto from "node:crypto";
import { NextFunction, Request, Response } from "express";
import * as Sentry from "@sentry/node";
import { logStructured } from "./structured-logger";

if (process.env.SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    tracesSampleRate: Number(process.env.SENTRY_TRACES_SAMPLE_RATE ?? 0.1),
    environment: process.env.APP_ENV ?? process.env.NODE_ENV
  });
}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const origins = (process.env.CORS_ORIGINS ?? "http://localhost:3000")
    .split(",")
    .map((origin) => origin.trim());

  const productionOrigin = "https://web-mu-ten-93.vercel.app";
  if (!origins.includes(productionOrigin)) {
    origins.push(productionOrigin);
  }

  console.log(`[API] Configuring CORS for origins: ${origins.join(", ")}`);

  app.enableCors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like mobile apps or curl)
      if (!origin) return callback(null, true);

      if (
        origins.indexOf(origin) !== -1 ||
        origin.startsWith("http://localhost:") ||
        origin.endsWith(".vercel.app") // Allow all Vercel previews as well
      ) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["content-type", "authorization", "x-api-key", "x-csrf-token", "idempotency-key"]
  });

  app.use(cookieParser());

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: []
        }
      },
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
      }
    })
  );

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidUnknownValues: true
    })
  );

  // CSRF protection using Double Submit Cookie pattern
  app.use((req: Request, res: Response, next: NextFunction) => {
    const start = Date.now();

    // Issue a CSRF token — set it as a non-HttpOnly cookie (so JS can read it)
    // and also return it in the response body
    if (req.method === "GET" && req.path === "/auth/csrf") {
      const token = crypto.randomBytes(32).toString("hex");
      res.cookie("__csrf", token, {
        httpOnly: false,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/",
        maxAge: 60 * 60 * 1000 // 1 hour
      });
      return res.json({ csrfToken: token });
    }

    // Validate CSRF on mutating requests to /auth/*
    if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method) && req.path.startsWith("/auth")) {
      const headerToken = req.headers["x-csrf-token"] as string | undefined;
      const cookieToken = req.cookies?.__csrf as string | undefined;

      if (!headerToken || !cookieToken) {
        return res.status(403).json({ error: { message: "Missing CSRF token", status: 403 } });
      }

      // Timing-safe comparison to prevent timing attacks
      if (headerToken.length !== cookieToken.length) {
        return res.status(403).json({ error: { message: "Invalid CSRF token", status: 403 } });
      }

      const headerBuf = Buffer.from(headerToken, "utf-8");
      const cookieBuf = Buffer.from(cookieToken, "utf-8");
      if (!crypto.timingSafeEqual(headerBuf, cookieBuf)) {
        return res.status(403).json({ error: { message: "Invalid CSRF token", status: 403 } });
      }
    }

    res.on("finish", () => {
      logStructured("info", "http_request", {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        durationMs: Date.now() - start,
        requestId: req.headers["x-request-id"] ?? null
      });
    });

    next();
  });

  app.useGlobalGuards(new ApiKeyGuard());
  app.useGlobalFilters(new GlobalErrorFilter());

  const port = process.env.PORT ? Number(process.env.PORT) : 4000;
  await app.listen(port);
  logStructured("info", "api_started", { port });
}

bootstrap().catch((error) => {
  logStructured("error", "bootstrap_failed", { error: error instanceof Error ? error.message : String(error) });
  if (process.env.SENTRY_DSN) {
    Sentry.captureException(error);
  }
  process.exit(1);
});
