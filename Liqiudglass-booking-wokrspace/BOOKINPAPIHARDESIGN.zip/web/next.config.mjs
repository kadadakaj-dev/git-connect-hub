import nextPWA from "@ducanh2912/next-pwa";

const withPWA = nextPWA({
  dest: "public",
  disable: process.env.NODE_ENV === "development",
  register: true,
  skipWaiting: false,
  fallbacks: {
    document: "/~offline"
  },
  workboxOptions: {
    runtimeCaching: [
      {
        // Next.js build artifacts — immutable, cache forever
        urlPattern: /^\/_next\/static\/.*/i,
        handler: "CacheFirst",
        options: {
          cacheName: "static-assets",
          expiration: { maxEntries: 200, maxAgeSeconds: 365 * 24 * 60 * 60 }
        }
      },
      {
        // Next.js optimized images
        urlPattern: /^\/_next\/image\?.*/i,
        handler: "StaleWhileRevalidate",
        options: {
          cacheName: "next-images",
          expiration: { maxEntries: 100, maxAgeSeconds: 30 * 24 * 60 * 60 }
        }
      },
      {
        // Static image/font assets
        urlPattern: /\.(?:png|jpg|jpeg|svg|gif|webp|ico|woff2?)$/i,
        handler: "CacheFirst",
        options: {
          cacheName: "media-assets",
          expiration: { maxEntries: 100, maxAgeSeconds: 30 * 24 * 60 * 60 }
        }
      },
      {
        // API calls — prefer network, fall back to cache
        urlPattern: ({ url }) => url.pathname.startsWith("/api") || url.origin !== self.location?.origin,
        handler: "NetworkFirst",
        options: {
          cacheName: "api-cache",
          networkTimeoutSeconds: 3,
          expiration: { maxEntries: 50, maxAgeSeconds: 5 * 60 }
        }
      },
      {
        // HTML pages — prefer network
        urlPattern: /^\/(?!_next|api).*/i,
        handler: "NetworkFirst",
        options: {
          cacheName: "pages-cache",
          expiration: { maxEntries: 50, maxAgeSeconds: 24 * 60 * 60 }
        }
      }
    ]
  }
});

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  /**
   * Security Headers Configuration
   * 
   * These headers are applied to all routes to protect against common web vulnerabilities.
   * For production deployments, consider using a CDN or reverse proxy to set additional headers.
   */
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          // Prevent clickjacking attacks by disallowing the page to be embedded in frames
          { key: "X-Frame-Options", value: "DENY" },

          // Prevent MIME-type sniffing, which can lead to unwanted code execution
          { key: "X-Content-Type-Options", value: "nosniff" },

          // Control how much referrer information is shared with external sites
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },

          /**
           * Content Security Policy (CSP)
           * 
           * Controls which resources can be loaded to prevent XSS and data injection attacks.
           * 
           * NOTE: 'unsafe-inline' and 'unsafe-eval' are used for Next.js compatibility:
           * - 'unsafe-eval' is required for Next.js runtime and hot module replacement
           * - 'unsafe-inline' is needed for styled-jsx and Next.js inline scripts/styles
           * 
           * For stricter security, consider implementing nonce-based CSP in production.
           */
          {
            key: "Content-Security-Policy",
            value: [
              // Default fallback: only load resources from same origin
              "default-src 'self'",

              // Scripts: allow own origin + unsafe directives for Next.js functionality
              "script-src 'self' 'unsafe-eval' 'unsafe-inline'",

              // Styles: allow own origin + inline styles (for CSS-in-JS and Next.js)
              "style-src 'self' 'unsafe-inline'",

              // Images: allow own origin, data URIs (for inline images), and blob URIs
              "img-src 'self' data: blob:",

              // Fonts: only from same origin
              "font-src 'self'",

              // API connections: allow own origin + NestJS API + Supabase
              // Use trim and regex to strip any stray newlines or whitespace from env values
              "connect-src 'self' " + [
                process.env.NEXT_PUBLIC_API_BASE,
                process.env.NEXT_PUBLIC_SUPABASE_URL
              ]
                .filter(Boolean)
                .map(url => url.trim().replace(/[\n\r\s\t]/g, ""))
                .filter(url => url && !url.startsWith("http://localhost"))
                .join(" "),

              // Prevent embedding in any iframe (redundant with X-Frame-Options but more modern)
              "frame-ancestors 'none'",

              // Restrict the URLs which can appear in a page's <base> element
              "base-uri 'self'",

              // Restrict where forms can be submitted
              "form-action 'self'"
            ].join("; ")
          },

          /**
           * Permissions Policy (formerly Feature Policy)
           * 
           * Disables potentially sensitive browser features that this app doesn't use.
           * This prevents malicious scripts from accessing camera, microphone, or location.
           */
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()"
          }
        ]
      }
    ];
  }
};

export default withPWA(nextConfig);
