"use client";

import { useEffect, useState } from "react";

export function SwUpdateToast() {
    const [showReload, setShowReload] = useState(false);
    const [waitingWorker, setWaitingWorker] = useState<ServiceWorker | null>(null);

    useEffect(() => {
        if (!("serviceWorker" in navigator)) return;

        const handleControllerChange = () => {
            window.location.reload();
        };

        const checkWaiting = (reg: ServiceWorkerRegistration) => {
            if (reg.waiting) {
                setWaitingWorker(reg.waiting);
                setShowReload(true);
            }
        };

        const handleStateChange = (event: Event) => {
            const sw = event.target as ServiceWorker;
            if (sw.state === "installed") {
                setWaitingWorker(sw);
                setShowReload(true);
            }
        };

        const handleRegistration = async () => {
            const reg = await navigator.serviceWorker.getRegistration();
            if (!reg) return;

            checkWaiting(reg);

            reg.addEventListener("updatefound", () => {
                const newWorker = reg.installing;
                if (newWorker) {
                    newWorker.addEventListener("statechange", handleStateChange);
                }
            });
        };

        navigator.serviceWorker.addEventListener("controllerchange", handleControllerChange);
        void handleRegistration();

        return () => {
            navigator.serviceWorker.removeEventListener("controllerchange", handleControllerChange);
        };
    }, []);

    const handleUpdate = () => {
        if (waitingWorker) {
            waitingWorker.postMessage({ type: "SKIP_WAITING" });
        }
        setShowReload(false);
    };

    if (!showReload) return null;

    return (
        <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md animate-slide-up">
            <div className="flex items-center justify-between gap-3 rounded-2xl bg-slate-900 px-4 py-3 text-sm text-white shadow-2xl">
                <span>New version available</span>
                <button
                    onClick={handleUpdate}
                    className="shrink-0 rounded-xl bg-blue-500 px-4 py-2 font-semibold text-white active:scale-95"
                >
                    Reload
                </button>
            </div>
        </div>
    );
}
