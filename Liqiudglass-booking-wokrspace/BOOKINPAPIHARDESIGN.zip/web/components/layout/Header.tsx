"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X, LogOut, LayoutDashboard } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

const NAV_LINKS = [
  { label: "Rezervácia", href: "/" },
  { label: "Cenník", href: "/#sluzby" },
  { label: "Kontakt", href: "https://papihairdesign.sk", external: true },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const { isAuthenticated, user, logout, loading } = useAuth();

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-100 bg-white/90 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-2xl items-center justify-between px-4">

        {/* Logo */}
        <Link href="/" className="flex items-center">
          <Image
            src="/logo-header.webp"
            alt="Papi Hair Design"
            width={120}
            height={40}
            priority
            className="h-9 w-auto object-contain"
          />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 sm:flex">
          {NAV_LINKS.map(({ label, href, external }) => (
            <Link
              key={href}
              href={href}
              target={external ? "_blank" : undefined}
              rel={external ? "noopener noreferrer" : undefined}
              className={`rounded-xl px-3 py-2 text-sm font-medium transition-colors ${
                isActive(href)
                  ? "bg-gray-100 text-gray-900"
                  : "text-gray-500 hover:bg-gray-50 hover:text-gray-800"
              }`}
            >
              {label}
            </Link>
          ))}
        </nav>

        {/* Right side: auth */}
        <div className="hidden items-center gap-2 sm:flex">
          {!loading && isAuthenticated ? (
            <>
              <Link
                href="/admin"
                className="flex items-center gap-1.5 rounded-xl bg-gray-900 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-gray-700"
              >
                <LayoutDashboard size={14} />
                Admin
              </Link>
              <button
                type="button"
                onClick={() => void logout()}
                title={user?.email}
                className="flex items-center gap-1.5 rounded-xl border border-gray-200 px-3 py-2 text-sm font-medium text-gray-500 transition-colors hover:border-gray-300 hover:text-gray-800"
              >
                <LogOut size={14} />
                Odhlásiť
              </button>
            </>
          ) : !loading ? (
            <Link
              href="/login"
              className="rounded-xl border border-gray-200 px-4 py-2 text-sm font-medium text-gray-600 transition-colors hover:border-gray-300 hover:text-gray-900"
            >
              Prihlásiť sa
            </Link>
          ) : null}
        </div>

        {/* Mobile hamburger */}
        <button
          type="button"
          className="flex items-center justify-center rounded-xl p-2 text-gray-500 hover:bg-gray-50 sm:hidden"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Menu"
        >
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile dropdown */}
      {menuOpen && (
        <div className="border-t border-gray-100 bg-white px-4 pb-4 sm:hidden">
          <nav className="mt-2 flex flex-col gap-1">
            {NAV_LINKS.map(({ label, href, external }) => (
              <Link
                key={href}
                href={href}
                target={external ? "_blank" : undefined}
                rel={external ? "noopener noreferrer" : undefined}
                onClick={() => setMenuOpen(false)}
                className={`rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive(href)
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}
              >
                {label}
              </Link>
            ))}

            {!loading && isAuthenticated && (
              <>
                <Link
                  href="/admin"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 rounded-xl bg-gray-900 px-3 py-2.5 text-sm font-medium text-white"
                >
                  <LayoutDashboard size={14} />
                  Admin panel
                </Link>
                <button
                  type="button"
                  onClick={() => { void logout(); setMenuOpen(false); }}
                  className="flex items-center gap-2 rounded-xl border border-gray-200 px-3 py-2.5 text-sm font-medium text-gray-600"
                >
                  <LogOut size={14} />
                  Odhlásiť sa
                </button>
              </>
            )}

            {!loading && !isAuthenticated && (
              <Link
                href="/login"
                onClick={() => setMenuOpen(false)}
                className="rounded-xl border border-gray-200 px-3 py-2.5 text-sm font-medium text-gray-600"
              >
                Prihlásiť sa
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
