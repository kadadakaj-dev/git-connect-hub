"use client";

import { useEffect, useState } from "react";
import { getSupabaseClient, ServiceRow } from "../../utils/supabase/client";

export function ServiceManager() {
    const [services, setServices] = useState<ServiceRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [editingService, setEditingService] = useState<Partial<ServiceRow> | null>(null);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        fetchServices();
    }, []);

    const fetchServices = async () => {
        const supabase = getSupabaseClient();
        if (!supabase) return;

        setLoading(true);
        const { data, error } = await supabase
            .from("services")
            .select("*")
            .order("created_at", { ascending: false });

        if (!error && data) {
            setServices(data as ServiceRow[]);
        }
        setLoading(false);
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        const supabase = getSupabaseClient();
        if (!supabase || !editingService) return;

        setIsSaving(true);
        const payload = {
            title: editingService.title,
            description: editingService.description,
            price: Number(editingService.price),
            duration_min: Number(editingService.duration_min),
            is_active: editingService.is_active ?? true,
        };

        let error;
        if (editingService.id) {
            const { error: err } = await supabase
                .from("services")
                .update(payload)
                .eq("id", editingService.id);
            error = err;
        } else {
            const { error: err } = await supabase.from("services").insert([payload]);
            error = err;
        }

        if (!error) {
            setEditingService(null);
            await fetchServices();
        }
        setIsSaving(false);
    };

    const toggleStatus = async (service: ServiceRow) => {
        const supabase = getSupabaseClient();
        if (!supabase) return;

        const { error } = await supabase
            .from("services")
            .update({ is_active: !service.is_active })
            .eq("id", service.id);

        if (!error) {
            await fetchServices();
        }
    };

    const deleteService = async (id: string) => {
        if (!confirm("Naozaj chcete zmazať túto službu?")) return;
        const supabase = getSupabaseClient();
        if (!supabase) return;

        const { error } = await supabase.from("services").delete().eq("id", id);
        if (!error) {
            await fetchServices();
        }
    };

    return (
        <section className="glass-edge mt-6 rounded-2xl bg-white/80 p-6 shadow-[0_10px_30px_rgba(15,23,42,0.08)] backdrop-blur-2xl dark:bg-black/60">
            <div className="flex items-center justify-between mb-6">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight">Správa služieb</h2>
                    <p className="text-sm text-slate-500">Pridávajte, upravujte alebo deaktivujte služby salónu.</p>
                </div>
                <button
                    onClick={() => setEditingService({ title: "", price: 0, duration_min: 30, is_active: true })}
                    className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition-opacity hover:opacity-90 dark:bg-blue-500"
                >
                    Pridať službu
                </button>
            </div>

            {editingService && (
                <div className="mb-8 rounded-2xl bg-slate-50 p-6 dark:bg-[#1C1C1E]">
                    <h3 className="mb-4 text-lg font-semibold">
                        {editingService.id ? "Upraviť službu" : "Nová služba"}
                    </h3>
                    <form onSubmit={handleSave} className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-1">
                            <label htmlFor="service-title" className="text-xs font-medium text-slate-500">Názov služby</label>
                            <input
                                id="service-title"
                                required
                                type="text"
                                value={editingService.title || ""}
                                onChange={(e) => setEditingService({ ...editingService, title: e.target.value })}
                                className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm dark:border-slate-800 dark:bg-black"
                                placeholder="napr. Dámsky strih"
                            />
                        </div>
                        <div className="space-y-1">
                            <label htmlFor="service-price" className="text-xs font-medium text-slate-500">Cena (€)</label>
                            <input
                                id="service-price"
                                required
                                type="number"
                                step="0.01"
                                title="Cena služby v eurách"
                                placeholder="0.00"
                                value={editingService.price || 0}
                                onChange={(e) => setEditingService({ ...editingService, price: Number(e.target.value) })}
                                className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm dark:border-slate-800 dark:bg-black"
                            />
                        </div>
                        <div className="space-y-1">
                            <label htmlFor="service-duration" className="text-xs font-medium text-slate-500">Trvanie (min)</label>
                            <input
                                id="service-duration"
                                required
                                type="number"
                                title="Trvanie služby v minútach"
                                placeholder="30"
                                value={editingService.duration_min || 0}
                                onChange={(e) => setEditingService({ ...editingService, duration_min: Number(e.target.value) })}
                                className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm dark:border-slate-800 dark:bg-black"
                            />
                        </div>
                        <div className="space-y-1">
                            <label htmlFor="service-description" className="text-xs font-medium text-slate-500">Popis (voliteľné)</label>
                            <input
                                id="service-description"
                                type="text"
                                title="Stručný popis služby"
                                placeholder="Stručný popis"
                                value={editingService.description || ""}
                                onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                                className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-sm dark:border-slate-800 dark:bg-black"
                            />
                        </div>
                        <div className="flex items-center gap-4 md:col-span-2">
                            <button
                                disabled={isSaving}
                                type="submit"
                                className="rounded-lg bg-blue-600 px-6 py-2 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                            >
                                {isSaving ? "Ukladám..." : "Uložiť zmeny"}
                            </button>
                            <button
                                type="button"
                                onClick={() => setEditingService(null)}
                                className="text-sm font-medium text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                            >
                                Zrušiť
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {loading ? (
                <div className="py-10 text-center text-sm text-slate-500">Načítavam služby...</div>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead>
                            <tr className="border-b border-slate-100 dark:border-slate-800">
                                <th className="pb-3 font-semibold text-slate-500">Služba</th>
                                <th className="pb-3 font-semibold text-slate-500">Trvanie</th>
                                <th className="pb-3 font-semibold text-slate-500">Cena</th>
                                <th className="pb-3 font-semibold text-slate-500">Stav</th>
                                <th className="pb-3 font-semibold text-slate-500 text-right">Akcie</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 dark:divide-slate-900">
                            {services.map((service) => (
                                <tr key={service.id} className="group transition-colors hover:bg-slate-50/50 dark:hover:bg-white/5">
                                    <td className="py-4">
                                        <p className="font-semibold">{service.title}</p>
                                        {service.description && (
                                            <p className="text-xs text-slate-400 mt-0.5">{service.description}</p>
                                        )}
                                    </td>
                                    <td className="py-4 text-slate-600 dark:text-slate-400">{service.duration_min} min</td>
                                    <td className="py-4 font-medium">{Number(service.price).toFixed(2)} €</td>
                                    <td className="py-4">
                                        <span
                                            className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${service.is_active
                                                ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                                                : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                                                }`}
                                        >
                                            {service.is_active ? "Aktívna" : "Neaktívna"}
                                        </span>
                                    </td>
                                    <td className="py-4 text-right">
                                        <div className="flex items-center justify-end gap-3">
                                            <button
                                                onClick={() => toggleStatus(service)}
                                                className="text-xs font-medium text-blue-600 hover:underline dark:text-blue-400"
                                            >
                                                {service.is_active ? "Deaktivovať" : "Aktivovať"}
                                            </button>
                                            <button
                                                onClick={() => setEditingService(service)}
                                                className="text-xs font-medium text-slate-600 hover:underline dark:text-slate-400"
                                            >
                                                Upraviť
                                            </button>
                                            <button
                                                onClick={() => deleteService(service.id)}
                                                className="text-xs font-medium text-red-600 hover:underline dark:text-red-400"
                                            >
                                                Zmazať
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            {services.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="py-10 text-center text-slate-400">
                                        Žiadne služby neboli nájdené.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            )}
        </section>
    );
}
