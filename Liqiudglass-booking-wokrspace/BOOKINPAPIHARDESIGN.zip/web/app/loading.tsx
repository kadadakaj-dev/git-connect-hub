export default function Loading() {
    return (
        <main className="min-h-screen bg-[#F2F2F7] p-4 dark:bg-black">
            <div className="mx-auto max-w-md space-y-4 animate-pulse">
                {/* Auth card skeleton */}
                <div className="rounded-2xl bg-white p-4 shadow-sm dark:bg-[#1C1C1E]">
                    <div className="h-4 w-24 rounded bg-slate-200 dark:bg-zinc-700" />
                    <div className="mt-2 h-5 w-48 rounded bg-slate-200 dark:bg-zinc-700" />
                    <div className="mt-3 flex gap-2">
                        <div className="h-12 w-40 rounded-xl bg-slate-200 dark:bg-zinc-700" />
                        <div className="h-12 w-20 rounded-xl bg-slate-200 dark:bg-zinc-700" />
                    </div>
                </div>

                {/* Services skeleton */}
                <div className="rounded-2xl bg-white p-4 shadow-sm dark:bg-[#1C1C1E]">
                    <div className="h-6 w-32 rounded bg-slate-200 dark:bg-zinc-700" />
                    <div className="mt-3 space-y-2">
                        <div className="h-12 w-full rounded-xl bg-slate-200 dark:bg-zinc-700" />
                        <div className="h-12 w-full rounded-xl bg-slate-200 dark:bg-zinc-700" />
                        <div className="h-12 w-full rounded-xl bg-slate-200 dark:bg-zinc-700" />
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <div key={i} className="h-10 w-16 rounded-full bg-slate-200 dark:bg-zinc-700" />
                        ))}
                    </div>
                </div>
            </div>
        </main>
    );
}
