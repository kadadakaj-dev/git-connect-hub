import Link from "next/link";

export default function NotFound() {
    return (
        <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 p-6 text-center dark:bg-black dark:text-white">
            <div className="mx-auto max-w-sm">
                <p className="text-7xl font-bold text-slate-200 dark:text-zinc-800">404</p>

                <h1 className="mt-4 text-2xl font-semibold">Page not found</h1>

                <p className="mt-2 text-slate-500">
                    The page you&apos;re looking for doesn&apos;t exist or has been moved.
                </p>

                <Link
                    href="/"
                    className="mt-6 inline-block h-12 rounded-xl bg-blue-500 px-8 leading-[48px] font-semibold text-white active:scale-95"
                >
                    Go Home
                </Link>
            </div>
        </main>
    );
}
