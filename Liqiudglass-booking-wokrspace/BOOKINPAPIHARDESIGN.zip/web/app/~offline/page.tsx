"use client";

import { useEffect, useState } from "react";

export default function OfflinePage() {
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    const updateStatus = () => {
      if (navigator.onLine) {
        setIsOnline(true);
        // Auto-redirect after brief delay when back online
        setTimeout(() => window.location.replace("/"), 1000);
      } else {
        setIsOnline(false);
      }
    };

    window.addEventListener("online", updateStatus);
    window.addEventListener("offline", updateStatus);

    return () => {
      window.removeEventListener("online", updateStatus);
      window.removeEventListener("offline", updateStatus);
    };
  }, []);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 p-6 text-center dark:bg-black dark:text-white">
      <div className="mx-auto max-w-sm">
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-slate-200 dark:bg-zinc-800">
          <svg
            className="h-10 w-10 text-slate-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
            />
          </svg>
        </div>

        <h1 className="text-2xl font-semibold">You are offline</h1>

        <p className="mt-2 text-slate-500">
          The dashboard is unavailable right now. Check your internet connection
          and try again.
        </p>

        {isOnline ? (
          <p className="mt-6 text-sm font-medium text-emerald-600">
            Connection restored — redirecting…
          </p>
        ) : (
          <button
            onClick={() => window.location.reload()}
            className="mt-6 h-12 w-full rounded-xl bg-blue-500 font-semibold text-white active:scale-95"
          >
            Try Again
          </button>
        )}
      </div>
    </main>
  );
}
