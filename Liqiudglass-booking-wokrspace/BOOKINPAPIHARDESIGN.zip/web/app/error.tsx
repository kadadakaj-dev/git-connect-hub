"use client";

import * as Sentry from "@sentry/nextjs";
import { useEffect } from "react";

export default function GlobalError({
    error,
    reset
}: {
    error: Error & { digest?: string };
    reset: () => void;
}) {
    useEffect(() => {
        Sentry.captureException(error);
    }, [error]);

    return (
        <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 p-6 text-center dark:bg-black dark:text-white">
            <div className="mx-auto max-w-sm">
                <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                    <svg
                        className="h-10 w-10 text-red-500"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={1.5}
                        aria-hidden="true"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z"
                        />
                    </svg>
                </div>

                <h1 className="text-2xl font-semibold">Something went wrong</h1>

                <p className="mt-2 text-slate-500">
                    An unexpected error occurred. Our team has been notified.
                </p>

                {error.digest && (
                    <p className="mt-1 font-mono text-xs text-slate-400">
                        Error ID: {error.digest}
                    </p>
                )}

                <button
                    onClick={reset}
                    className="mt-6 h-12 w-full rounded-xl bg-blue-500 font-semibold text-white active:scale-95"
                >
                    Try Again
                </button>
            </div>
        </main>
    );
}
