"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { LiveCalendar } from "./components/LiveCalendar";
import { RevenueChart } from "../../components/dashboard/RevenueChart";
import { StatsGrid } from "../../components/dashboard/StatsGrid";
import { ServiceManager } from "../../components/dashboard/ServiceManager";
import { calculateOccupancyRate } from "../../components/dashboard/statsUtils";
import { useRealtimeBookings } from "../../hooks/useRealtimeBookings";
import { BookingRow, getSupabaseClient } from "../../utils/supabase/client";

const FALLBACK_OPENING_HOURS_PER_DAY = 10;

export default function AdminPage() {
  const { bookings, feed, bookingsToday, loading, error } = useRealtimeBookings();
  const [currency, setCurrency] = useState("EUR");

  const updateBookingStatus = useCallback(async (bookingId: string, status: BookingRow["status"]) => {
    const supabase = getSupabaseClient();
    if (!supabase) return;
    await supabase.from("bookings").update({ status }).eq("id", bookingId);
  }, []);

  useEffect(() => {
    const supabase = getSupabaseClient();
    if (!supabase) return;

    const loadSettings = async () => {
      const { data: settings } = await supabase
        .from("business_settings")
        .select("currency")
        .limit(1)
        .maybeSingle();
      if (settings?.currency) setCurrency(settings.currency);
    };

    void loadSettings();
  }, []);

  // Revenue from real bookings (confirmed + completed) in the last 30 days
  const totalRevenue = useMemo(() => {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    return bookings
      .filter(
        (b) =>
          (b.status === "confirmed" || b.status === "completed") &&
          new Date(b.start_time).getTime() >= cutoff
      )
      .reduce((sum, b) => sum + Number(b.services?.price ?? 0), 0);
  }, [bookings]);

  const occupancyRate = useMemo(() => {
    const totalOpeningHoursWeekly = FALLBACK_OPENING_HOURS_PER_DAY * 7;
    return calculateOccupancyRate(bookings, totalOpeningHoursWeekly);
  }, [bookings]);

  const chartData = useMemo(() => {
    const perDay = new Map<string, number>();
    for (const booking of bookings) {
      if (booking.status === "cancelled") continue;
      const dayLabel = new Date(booking.start_time).toLocaleDateString("sk-SK", {
        month: "short",
        day: "numeric"
      });
      const current = perDay.get(dayLabel) ?? 0;
      perDay.set(dayLabel, current + Number(booking.services?.price ?? 0));
    }

    return Array.from(perDay.entries())
      .map(([label, value]) => ({ label, value }))
      .slice(-14);
  }, [bookings]);

  return (
    <main className="min-h-screen bg-[#F2F2F7] p-4 dark:bg-black dark:text-white md:p-6">
      <div className="mx-auto grid max-w-7xl gap-4">
        <header className="glass-edge rounded-2xl bg-white/80 p-5 shadow-[0_10px_30px_rgba(15,23,42,0.08)] backdrop-blur-2xl dark:bg-black/60">
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">Rezervácie v reálnom čase — prehľad a správa.</p>
        </header>

        {error && (
          <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700 dark:bg-red-900/20 dark:text-red-300">
            {error}
          </div>
        )}

        {loading ? (
          <div className="glass-edge rounded-2xl bg-white/80 p-6 backdrop-blur-2xl dark:bg-black/60">
            Načítavam...
          </div>
        ) : (
          <>
            <StatsGrid
              revenue={totalRevenue}
              bookingsToday={bookingsToday}
              occupancyRate={occupancyRate}
              feed={feed}
              currency={currency}
            />
            <RevenueChart data={chartData} />
            <LiveCalendar
              bookings={bookings}
              onApprove={(id) => void updateBookingStatus(id, "confirmed")}
              onCancel={(id) => void updateBookingStatus(id, "cancelled")}
            />
            <ServiceManager />
          </>
        )}
      </div>
    </main>
  );
}
