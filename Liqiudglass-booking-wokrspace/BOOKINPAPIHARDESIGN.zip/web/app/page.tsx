"use client";

import { useEffect, useMemo, useState } from "react";
import { ChevronDown, ChevronUp, Clock, ShieldCheck, CheckCircle2, Loader2 } from "lucide-react";
import { getSupabaseClient } from "../utils/supabase/client";

type DbService = {
  id: number;
  title: string;
  price: number;
  duration_min: number;
  gender: string;
  category: string;
};

type Category = { name: string; services: DbService[] };

type Step = "service" | "time" | "contact" | "done";

const TIME_SLOTS = [
  "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
  "11:00", "11:30", "12:00", "13:00", "13:30", "14:00",
  "14:30", "15:00", "15:30", "16:00", "16:30", "17:00",
];

function buildCategories(services: DbService[], gender: string): Category[] {
  const filtered = services.filter((s) => s.gender === gender);
  const map = new Map<string, DbService[]>();
  for (const s of filtered) {
    if (!map.has(s.category)) map.set(s.category, []);
    map.get(s.category)!.push(s);
  }
  return Array.from(map.entries()).map(([name, svcs]) => ({ name, services: svcs }));
}

function addMinutes(slot: string, minutes: number): string {
  const [h, m] = slot.split(":").map(Number);
  const total = h * 60 + m + minutes;
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

export default function Page() {
  const [services, setServices] = useState<DbService[]>([]);
  const [loadError, setLoadError] = useState(false);
  const [gender, setGender] = useState<"damsky" | "pansky">("damsky");
  const [openCategories, setOpenCategories] = useState<Set<string>>(new Set());
  const [serviceId, setServiceId] = useState<number | null>(null);
  const [slot, setSlot] = useState<string | null>(null);
  const [step, setStep] = useState<Step>("service");

  // Contact form
  const [name, setName]   = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  useEffect(() => {
    const sb = getSupabaseClient();
    if (!sb) return;
    sb.from("services")
      .select("id, title, price, duration_min, gender, category")
      .eq("is_active", true)
      .order("id")
      .then(({ data, error }) => {
        if (error || !data) { setLoadError(true); return; }
        setServices(data as DbService[]);
      });
  }, []);

  const categories = useMemo(() => buildCategories(services, gender), [services, gender]);

  useEffect(() => {
    setServiceId(null);
    setSlot(null);
    setStep("service");
    if (categories.length > 0) setOpenCategories(new Set([categories[0].name]));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gender, categories.length]);

  useEffect(() => { setSlot(null); }, [serviceId]);

  const selectedService = useMemo(
    () => services.find((s) => s.id === serviceId) ?? null,
    [services, serviceId]
  );

  const toggleCategory = (name: string) => {
    setOpenCategories((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  };

  async function handleBook() {
    if (!selectedService || !slot || !name.trim() || !phone.trim()) return;
    setSubmitting(true);
    setSubmitError(null);
    const sb = getSupabaseClient();
    if (!sb) { setSubmitError("Chyba pripojenia."); setSubmitting(false); return; }

    const today = new Date().toISOString().split("T")[0];
    const start = `${today}T${slot}:00`;
    const end   = `${today}T${addMinutes(slot, selectedService.duration_min)}:00`;

    const { error } = await sb.from("bookings").insert({
      service_id:     selectedService.id,
      start_time:     start,
      end_time:       end,
      status:         "pending",
      customer_name:  name.trim(),
      customer_phone: phone.trim(),
      customer_email: email.trim() || null,
      notes:          notes.trim() || null,
    });

    if (error) {
      setSubmitError("Rezerváciu sa nepodarilo uložiť. Skúste znova.");
      setSubmitting(false);
      return;
    }
    setStep("done");
    setSubmitting(false);
  }

  // ── DONE screen ──────────────────────────────────────────────
  if (step === "done") {
    return (
      <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-gray-50 px-4">
        <div className="w-full max-w-sm text-center">
          <CheckCircle2 size={56} className="mx-auto mb-4 text-green-500" />
          <h1 className="text-2xl font-bold text-gray-900">Rezervácia odoslaná!</h1>
          <p className="mt-2 text-sm text-gray-500">
            Potvrdzujeme vašu rezerváciu — čoskoro vás kontaktujeme.
          </p>
          <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-5 text-left shadow-sm">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Služba</span>
                <span className="font-medium text-gray-900">{selectedService?.title}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Čas</span>
                <span className="font-medium text-gray-900">{slot}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Meno</span>
                <span className="font-medium text-gray-900">{name}</span>
              </div>
              <div className="flex justify-between border-t border-gray-100 pt-2">
                <span className="font-semibold text-gray-900">Celkom</span>
                <span className="font-bold text-blue-600">{selectedService?.price.toFixed(2)} €</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setStep("service"); setServiceId(null); setSlot(null);
              setName(""); setPhone(""); setEmail(""); setNotes("");
            }}
            className="mt-6 w-full rounded-2xl border border-gray-200 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50"
          >
            Nová rezervácia
          </button>
        </div>
      </main>
    );
  }

  // ── MAIN flow ────────────────────────────────────────────────
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-2xl px-4 py-8">

        {/* Gender tabs */}
        <div id="sluzby" className="mb-6 flex rounded-2xl border border-gray-200 bg-white p-1 shadow-sm">
          {(["damsky", "pansky"] as const).map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => setGender(g)}
              className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all ${
                gender === g ? "bg-gray-900 text-white shadow-sm" : "text-gray-500 hover:text-gray-800"
              }`}
            >
              {g === "damsky" ? "Dámsky cenník" : "Pánsky cenník"}
            </button>
          ))}
        </div>

        {/* KROK 1 – Výber služby */}
        <div className="mb-6">
          <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">
            1. Vyberte službu
          </p>

          {loadError && (
            <p className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-500">
              Nepodarilo sa načítať služby. Skúste obnoviť stránku.
            </p>
          )}
          {!loadError && services.length === 0 && (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => <div key={i} className="h-12 animate-pulse rounded-2xl bg-gray-100" />)}
            </div>
          )}

          <div className="space-y-2">
            {categories.map((cat) => {
              const isOpen = openCategories.has(cat.name);
              return (
                <div key={cat.name} className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
                  <button
                    type="button"
                    onClick={() => toggleCategory(cat.name)}
                    className="flex w-full items-center justify-between px-4 py-3 text-left"
                  >
                    <span className="font-semibold text-gray-800">{cat.name}</span>
                    {isOpen ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                  </button>
                  {isOpen && (
                    <div className="border-t border-gray-100">
                      {cat.services.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => { setServiceId(s.id); setStep("time"); }}
                          className={`flex w-full items-center justify-between px-4 py-3 text-left transition-colors ${
                            serviceId === s.id ? "bg-blue-50" : "hover:bg-gray-50"
                          }`}
                        >
                          <div>
                            <p className={`text-sm font-medium ${serviceId === s.id ? "text-blue-700" : "text-gray-800"}`}>
                              {s.title}
                            </p>
                            <p className="mt-0.5 flex items-center gap-1 text-xs text-gray-400">
                              <Clock size={11} /> {s.duration_min} min
                            </p>
                          </div>
                          <span className={`text-sm font-bold ${serviceId === s.id ? "text-blue-600" : "text-gray-700"}`}>
                            {s.price.toFixed(2)} €
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* KROK 2 – Výber času */}
        {selectedService && (
          <div className="mb-6">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">
              2. Vyberte čas
            </p>
            <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-6 [&>button]:min-h-[44px]">
                {TIME_SLOTS.map((time) => (
                  <button
                    key={time}
                    type="button"
                    onClick={() => { setSlot(time); setStep("contact"); }}
                    className={`rounded-xl border py-2.5 text-sm font-medium transition-all ${
                      slot === time
                        ? "border-blue-500 bg-blue-500 text-white"
                        : "border-gray-200 text-gray-700 hover:border-blue-300 hover:text-blue-600"
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* KROK 3 – Kontaktné údaje */}
        {selectedService && slot && step === "contact" && (
          <div className="mb-6">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">
              3. Vaše údaje
            </p>
            <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
              <div className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    Meno a priezvisko <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ján Novák"
                    className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-base sm:text-sm outline-none focus:border-gray-400 focus:ring-2 focus:ring-gray-100"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    Telefón <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="tel"
                    inputMode="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+421 900 000 000"
                    className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-base sm:text-sm outline-none focus:border-gray-400 focus:ring-2 focus:ring-gray-100"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    E-mail <span className="text-gray-400 text-xs font-normal">(nepovinné)</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jan@email.sk"
                    className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-base sm:text-sm outline-none focus:border-gray-400 focus:ring-2 focus:ring-gray-100"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    Poznámka <span className="text-gray-400 text-xs font-normal">(nepovinné)</span>
                  </label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Napr. prvá návšteva, alergia na farbu..."
                    rows={2}
                    className="w-full resize-none rounded-xl border border-gray-200 px-3.5 py-2.5 text-base sm:text-sm outline-none focus:border-gray-400 focus:ring-2 focus:ring-gray-100"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Zhrnutie */}
        {selectedService && slot && (
          <div className="mb-5 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
            <h3 className="mb-3 font-semibold text-gray-900">Zhrnutie</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Služba</span>
                <span className="font-medium text-gray-900">{selectedService.title}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Trvanie</span>
                <span className="font-medium text-gray-900">{selectedService.duration_min} min</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Čas</span>
                <span className="font-medium text-gray-900">{slot}</span>
              </div>
              <div className="flex justify-between border-t border-gray-100 pt-2">
                <span className="font-semibold text-gray-900">Celkom</span>
                <span className="font-bold text-blue-600">{selectedService.price.toFixed(2)} €</span>
              </div>
            </div>
          </div>
        )}

        {submitError && (
          <p className="mb-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-500">{submitError}</p>
        )}

        {/* CTA tlačidlo */}
        <button
          type="button"
          disabled={!selectedService || !slot || (step === "contact" && (!name.trim() || !phone.trim())) || submitting}
          onClick={step === "contact" ? handleBook : undefined}
          className="h-14 w-full rounded-2xl bg-blue-500 text-base font-semibold text-white shadow-sm transition-all hover:bg-blue-600 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {submitting ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 size={18} className="animate-spin" /> Odosielam...
            </span>
          ) : step === "contact" && selectedService && slot ? (
            `Rezervovať – ${selectedService.title} o ${slot}`
          ) : selectedService && slot ? (
            "Vyplňte kontaktné údaje"
          ) : (
            "Vyberte službu a čas"
          )}
        </button>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-gray-400">
          <ShieldCheck size={13} /> Zabezpečené – vaše údaje sú v bezpečí
        </p>

      </div>
    </main>
  );
}
